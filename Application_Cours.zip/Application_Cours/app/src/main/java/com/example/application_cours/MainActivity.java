package com.example.application_cours;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private Button b_acces_cree_zone;
    private Button b_acces_releve_effectuer;
    private Button b_acces_gestion_types;
    private Button b_acces_saisie_releve;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        b_acces_cree_zone = findViewById(R.id.b_acces_cree_zone);
        b_acces_releve_effectuer = findViewById(R.id.b_acces_releve_effectuer);
        b_acces_gestion_types = findViewById(R.id.b_acces_gestion_types);
        b_acces_saisie_releve = findViewById(R.id.b_acces_saisie_releve);




        if (Modele.lesZones.isEmpty()) {
            Modele.lesZones.add(new Zone("A3"));
            Modele.lesZones.get(0).getLesTypes().add("Pesticides");
            Modele.lesZones.get(0).getLesTypes().add("Hydrocarbures");
            Modele.lesZones.get(0).getLesTypes().add("Pesticides");

            Modele.lesZones.add(new Zone("B2"));
            Modele.lesZones.get(1).getLesTypes().add("Pesticides");
            Modele.lesZones.get(1).getLesTypes().add("Chlorophenols");

            Modele.listeType.add(new TypeReleve("Métaux Lourds", "mg/kg"));
            Modele.listeType.add(new TypeReleve("PCB", "ng/kg"));
            Modele.listeType.add(new TypeReleve("Pesticides", "µg/L"));


        }
        for( int i=0;i<Modele.lesZones.size();i++) {
            Log.d("testLog",Modele.lesZones.get(i).getNom());
            for(int j=0;j<Modele.lesZones.get(i).getLesTypes().size();j++){
                Log.d("testLog",Modele.lesZones.get(i).getLesTypes().get(j));
            }
        }



        // ---- SECTION Button ---- //

        b_acces_cree_zone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent unIntent = new Intent(getApplicationContext(),creeZone.class);
                startActivity(unIntent);
            }
        });

        b_acces_releve_effectuer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent unIntent = new Intent(getApplicationContext(),releverEffectuer.class);
                startActivity(unIntent);
            }
        });

        b_acces_gestion_types.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent unIntent = new Intent(getApplicationContext(),gestionTypes.class);
                startActivity(unIntent);
            }
        });

        b_acces_saisie_releve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent unIntent = new Intent(getApplicationContext(),saisieReleve.class);
                startActivity(unIntent);
            }
        });
    }
}