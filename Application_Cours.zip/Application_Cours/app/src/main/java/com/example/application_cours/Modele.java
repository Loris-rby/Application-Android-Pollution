package com.example.application_cours;
import java.util.ArrayList;

public class Modele {

    public static ArrayList<TypeReleve> listeType = new ArrayList<>();
    public static ArrayList<Zone> lesZones = new ArrayList<>();

}