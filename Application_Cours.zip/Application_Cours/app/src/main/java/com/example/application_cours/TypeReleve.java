package com.example.application_cours;

public class TypeReleve {
    private String nomType;
    private String unite;

    public TypeReleve(String nomType, String unite) {
        this.nomType = nomType;
        this.unite = unite;
    }

    public String getNomType() {
        return nomType;
    }

    public String getUnite() {
        return unite;
    }

    public void setNomType(String nomType) {
        this.nomType = nomType;
    }

    public void setUnite(String unite) {
        this.unite = unite;
    }
}
