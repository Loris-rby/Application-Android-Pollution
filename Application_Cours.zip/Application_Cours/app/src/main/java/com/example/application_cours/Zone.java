package com.example.application_cours;
import java.util.ArrayList;

public class Zone {
    private String nom;
    private ArrayList<String> lesTypes;

    public Zone(String nom) {
        this.nom = nom;
        this.lesTypes = new ArrayList<>();
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public ArrayList<String> getLesTypes() {
        return lesTypes;
    }

    public void setLesTypes(ArrayList<String> lesTypes) {
        this.lesTypes = lesTypes;
    }
}
