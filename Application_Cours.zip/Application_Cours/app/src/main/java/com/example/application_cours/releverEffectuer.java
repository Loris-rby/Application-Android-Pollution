package com.example.application_cours;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class releverEffectuer extends AppCompatActivity {

    private Spinner s_choixZone, s_choixType;
    private TextView tv_afficheReleve;
    private Button b_retour;
    private Button b_ajouterReleve;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relever_effectuer);


        s_choixZone = findViewById(R.id.s_choixZone);
        s_choixType = findViewById(R.id.s_choixType);
        tv_afficheReleve = findViewById(R.id.tv_afficherReleve);
        b_retour = findViewById(R.id.b_retourReleve);
        b_ajouterReleve = findViewById(R.id.b_ajouterReleve);



        b_retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        ArrayAdapter<String> adapteurTypes = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
        for(int i=0;i<Modele.listeType.size();i++){
            adapteurTypes.add(Modele.listeType.get(i).getNomType());
        }
        s_choixType.setAdapter(adapteurTypes);


        ArrayAdapter<String> adapteurZones = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
        for(int i=0;i<Modele.lesZones.size();i++){
            adapteurZones.add(Modele.lesZones.get(i).getNom());
        }
        s_choixZone.setAdapter(adapteurZones);

/*
        b_ajouterReleve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomZone = s_choixZone.getSelectedItem().toString();
                String nomType = s_choixType.getSelectedItem().toString();


                for (Zone zone : Modele.lesZones){
                    if (zone.getNom() == nomZone){
                        int i = Modele.lesZones.toString().indexOf(nomZone);
                        Modele.lesZones.get(i).getLesTypes().add(nomType);
                    }
                else{
                    int i = Modele.lesZones.indexOf(nomZone);
                    Modele.lesZones.get(i).getLesTypes().add(nomType);
                }


                tv_afficheReleve.setText("");

                for(int i=0;i<Modele.lesZones.size();i++) {
                    for(int j=0;j<Modele.lesZones.get(i).getLesTypes().size();j++){
                        tv_afficheReleve.append(Modele.lesZones.get(i).getLesTypes().get(j));
                        tv_afficheReleve.append("\n");
                    };
                }
            }

 */


    }
}