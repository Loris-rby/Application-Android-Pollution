package com.example.application_cours;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class saisieReleve extends AppCompatActivity {

    private Button b_saisieReleve;
    private Spinner s_zone;
    private Spinner s_type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_saisie_releve);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        b_saisieReleve = findViewById(R.id.b_saisieReleve);
        s_zone = findViewById(R.id.s_zone);
        s_type = findViewById(R.id.s_type);

        // ---- Button SECTION ---- //

        b_saisieReleve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Type;
                String Zone;
                Type = s_type.getSelectedItem().toString();
                Zone = s_zone.getSelectedItem().toString();
                Log.d("testLog","Spinner : "+Type +"et " + Zone);
                finish();
            }
        });

    }
}